import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../model/note.dart';
import '../services/note_storage.dart';

class NoteEditor extends StatefulWidget {
  final Note? note;
  const NoteEditor({super.key, this.note});

  @override
  State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> {
  final titleController = TextEditingController();
  final contentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.note != null) {
      titleController.text = widget.note!.title;
      contentController.text = widget.note!.content;
    }
  }

  void _saveNote() async {
    final title = titleController.text.trim();
    final content = contentController.text.trim();
    if (title.isEmpty && content.isEmpty) return;

    final notes = await NoteStorage.loadNotes();
    final timestamp = DateTime.now().toString().split('.')[0];

    if (widget.note == null) {
      notes.add(Note(
        id: const Uuid().v4(),
        title: title,
        content: content,
        timestamp: timestamp,
      ));
    } else {
      final index = notes.indexWhere((n) => n.id == widget.note!.id);
      if (index != -1) {
        notes[index] = Note(
          id: widget.note!.id,
          title: title,
          content: content,
          timestamp: timestamp,
        );
      }
    }

    await NoteStorage.saveNotes(notes);
    Navigator.pop(context, true);
  }

  void _deleteNote() async {
    final notes = await NoteStorage.loadNotes();
    notes.removeWhere((n) => n.id == widget.note!.id);
    await NoteStorage.saveNotes(notes);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.note != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Note' : 'New Note'),
        actions: isEditing
            ? [IconButton(onPressed: _deleteNote, icon: Icon(Icons.delete))]
            : null,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(hintText: 'Title'),
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Expanded(
              child: TextField(
                controller: contentController,
                decoration: InputDecoration(hintText: 'Note...'),
                maxLines: null,
                expands: true,
              ),
            ),
            ElevatedButton(
              onPressed: _saveNote,
              child: Text('Save'),
            )
          ],
        ),
      ),
    );
  }
}
