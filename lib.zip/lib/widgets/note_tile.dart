import 'package:flutter/material.dart';
import '../model/note.dart';

class NoteTile extends StatelessWidget {
  final Note note;
  final VoidCallback onTap;

  const NoteTile({super.key, required this.note, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        title: Text(note.title,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
          '${note.content.split('\n').take(2).join('\n')}\n${note.timestamp}',
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
        onTap: onTap,
      ),
    );
  }
}
