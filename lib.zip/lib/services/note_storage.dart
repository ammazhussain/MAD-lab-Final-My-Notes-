import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../model/note.dart';

class NoteStorage {
  static const String _key = 'notes';

  static Future<List<Note>> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(_key) ?? [];
    return jsonList.map((e) => Note.fromJson(json.decode(e))).toList();
  }

  static Future<void> saveNotes(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = notes.map((note) => json.encode(note.toJson())).toList();
    await prefs.setStringList(_key, jsonList);
  }
}
